package com.AB.Test;

import org.testng.annotations.Test;

import com.AB.BasePackage.Base;
import com.AB.Pages.HomePage;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class HomePageTest extends Base {
	HomePage homePage;
	
	public HomePageTest() {
		super();
		}
	
	@BeforeMethod
	public void setUp() {
		Base.browserdriver();
		homePage=new HomePage();
		homePage.selcountryaudience();
	}
	
  @Test
  public void segmentInformationValidation() {
	  
	  WebElement segInfo= driver.findElement(By.xpath("//div[contains(text(),'Institutions - Americas')]"));
	  Boolean ele=segInfo.isDisplayed();
	  Assert.assertEquals(segInfo, "Institutions - Americas");
	  		
  }
  
  @Test
  public void countryflag() {
	 WebElement countryflag=driver.findElement(By.xpath("//div[@class='abl--gnav-toggle ab-flag-sprite flag-us']"));
			 Boolean cntflag=countryflag.isDisplayed();
			 Assert.assertTrue(cntflag);
  }
  
    
  @Test
  public void ABLogo() {
	  
	  WebElement logo=driver.findElement(By.xpath("//img[@src='https://www.alliancebernstein.com/resources/images/abui-branding-glp.png']"));
	  	Boolean logodisp=logo.isDisplayed();
	  	Assert.assertTrue(logodisp);
  }
  
  @AfterMethod
  public void end() {
	  driver.quit();
  }
  
}
	