package com.AB.Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.AB.BasePackage.Base;

public class HomePage extends Base {
	//public static  WebDriver driver;
	
			//locators or OR
			private By country = By.xpath("//a[contains(text(),'United States')]");
			private By audience = By.xpath("//a[contains(text(),'Institutions')]");
			private By termsconditions =By.xpath("//button[contains(text(),'Yes Continue')]");
			
			//Constructor that will be automatically called as soon as the object of the class is created
			public HomePage() {
				
				super();
			}
						
			
			//pageactions
			public void selcountryaudience() {
				driver.findElement(country).click();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
				driver.findElement(audience).click();
				driver.findElement(termsconditions).click();
				Base.pageloadtimeout("implicit", 10, null);
				
			}
			
//			public static void main(String[] args) {
//				HomePage pg=new HomePage();
//				//pg.props();
//				pg.browserdriver();
//				pg.selcountryaudience();
//			}
			
			
}
