package com.AB.BasePackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Base {
	public static Properties prop;
	public static WebDriver driver;
	public static  String implicit;
	public Base() {
		prop = new Properties();
		try {
			FileInputStream ip = new FileInputStream("D:/Assessment_ABFund/TestData.properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public static void browserdriver() {

		String browserName = prop.getProperty("browser");

		if (browserName.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		}
		if (browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		}
		if (browserName.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}
		driver.get(prop.getProperty("Url"));
		driver.manage().window().maximize();
		pageloadtimeout(implicit,10, null);
		driver.findElement(By.id("onetrust-accept-btn-handler")).click();
	}

	//findElement
	
	public WebElement findElement(String xpath) {
			
		
		
		return null;
		
	}
	
	
	//Take Screenshot
	public void Getscreenshot() {
		// convert webdriver object to take screenshot
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		// Call getscreenshotAs method to create image file
		File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
		//String screenshotBase64 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
		String path = System.getProperty("user.dir") + "/screenshot/" + ".png";
		File destination = new File(path);
		try {
			FileHandler.copy(srcFile, destination);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
    
	public static void pageloadtimeout(String waittype, int timeunit, WebElement element) {
		if(waittype=="implicit") {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeunit));
		}
		else if(waittype=="explicit")
		{

			WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(timeunit));
			wait.until(ExpectedConditions.visibilityOf(element));
		}
		else if(waittype=="fluentwait")
		{

			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
					.withTimeout(Duration.ofSeconds(timeunit))
					.pollingEvery(Duration.ofSeconds(timeunit))
					.ignoring(NoSuchElementException.class);
		}
		else if(waittype=="pageload") {
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(timeunit));
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		}
	}

		
	}
